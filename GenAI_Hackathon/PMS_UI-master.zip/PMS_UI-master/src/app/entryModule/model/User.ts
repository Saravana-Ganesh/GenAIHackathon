export class User{
    //emailId:string='';
    username:string='';
    password:string='';
    //roleId:string='';
}
/*
    Author:Nayana DK
*/
export interface IUserLogin{
    //email:string;
    username:string;
    password:string;
    //role:number;
}
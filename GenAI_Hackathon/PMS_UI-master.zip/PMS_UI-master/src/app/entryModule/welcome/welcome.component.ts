import { AfterContentInit, AfterViewChecked, AfterViewInit, Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
/*
    Author:Nayana DK
*/
export class WelcomeComponent implements OnInit {
  constructor() { }
 
  ngOnInit(): void {
  }
  
}

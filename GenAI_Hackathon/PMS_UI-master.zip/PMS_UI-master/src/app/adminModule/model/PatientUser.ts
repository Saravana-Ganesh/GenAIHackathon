export interface IPatientUser {
    patientId: string;
    firstName: string;
    lastName:string;
    emailId:string;
    dateOfBirth:string;
    dateOfRegistration: string;
    status: string;
    //link1?: string;
    //link2?: string;
    //edit: string;
}
export interface ApiResponse{
    statusCode:number
    statusMessage:string;    
    responseData:any
}

export interface SearchContent{
    searchText:string;
}
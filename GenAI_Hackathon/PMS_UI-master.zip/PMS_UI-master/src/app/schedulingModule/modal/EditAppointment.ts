export class EditAppointmentDetails
{
    editDateTime:string;
    createdBy:string;
    editReason:string;
    previousFromTime:string;
    previousToTime:string;
    meetingId:string
}
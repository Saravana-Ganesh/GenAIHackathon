export class Constants
{
    static  API_URL:string = "http://localhost:8080/";

    static SECURE_TOKEN = "SECURE_TOKEN";

    static LOGGED_IN_USER  = "LOGGED_IN_USER";
}
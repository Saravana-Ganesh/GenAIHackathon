export class Patient{
    patientId:number=0;
    patientFirstName:string="";
    patientLastName:string="";
    patientDOB:Date | undefined;
    patientGender:string="";
    patientEmailId:string="";
    patientRace:string="";
    patientEthinicity:string="";
}
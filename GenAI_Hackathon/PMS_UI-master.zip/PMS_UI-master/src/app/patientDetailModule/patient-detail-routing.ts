import { Routes } from "@angular/router";
import {PatientDetailsComponent} from "./patient-details/patient-details.component"
import {PatientDemographicsComponent} from "./patient-demographics/patient-demographics.component"
import { PatientVisitComponent } from "../patientVisitModule/patient-visit/patient-visit.component";

export const EntryRoutes: Routes = [
    //{path: "patientDetails",component:PatientDetailsComponent},
    //{path: "patientDemographic/:id",component:PatientDemographicsComponent},
   // {path: "patientVisit",component:PatientVisitComponent}
     
]   


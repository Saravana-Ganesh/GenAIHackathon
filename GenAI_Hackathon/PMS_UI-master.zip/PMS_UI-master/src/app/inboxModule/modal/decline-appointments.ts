export class DeclinedAppointments {
    title: string = "";
    description: string = "";
    physician: string = "";
    date?: Date;
    fromTime:string="";
    toTime: string = "";
    history: string = "";
    reason:string="";
    patient:string;
}

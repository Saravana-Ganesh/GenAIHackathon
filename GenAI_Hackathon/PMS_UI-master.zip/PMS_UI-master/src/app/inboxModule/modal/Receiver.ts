export class Receiver {
    emailId:string;
    id?: number;
    name?: string
    designation?: string
    accountStatus = ""
    deleteFlag?= ""
    dob = ""
    empId = ""
    firstName = ""
    gender = ""
    lastName = ""
    modified_by = ""
    modified_on = ""
    password = ""
    role = ""
    title = ""
    username = ""
    first_Name: any;
    emp_id: any;
}